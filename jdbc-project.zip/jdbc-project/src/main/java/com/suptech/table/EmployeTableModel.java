package com.suptech.table;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import com.suptech.model.Employe;

public class EmployeTableModel extends AbstractTableModel{
	//L'entête du JTable
	private final String[] cols= {"C1","C2","C3"};
	//Les données de JTABLE
	private List<Employe> data=new ArrayList<Employe>();

	private static final long serialVersionUID = 1L;
	
	
	public void setData(List<Employe> data) {
		this.data = data;
		//Pour capturer les changements des données
		fireTableDataChanged();
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return data.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return cols.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Employe e=data.get(rowIndex);
		switch(columnIndex) {
		case 0:return e.getMat();
		case 1:return e.getNom();
		case 2:return e.getSal();
		default: return null;
		}
		
	}

	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return cols[column];
	}
	

}
