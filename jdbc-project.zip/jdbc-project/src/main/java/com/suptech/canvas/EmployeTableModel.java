package com.suptech.canvas;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import com.suptech.model.Employe;

public class EmployeTableModel extends AbstractTableModel{
	
	private final String[] cols = {"Mat", "Nom", "Salaire"};
	private List<Employe> data = new ArrayList<>();
	@Override
	public String getColumnName(int column) {
		return cols[column];
	}
	public void setData(List<Employe> data) {
		this.data = data;
		fireTableDataChanged();
	}
	@Override
	public int getRowCount() {
		return data.size();
	}
	@Override
	public int getColumnCount() {
		return cols.length;
	}
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Employe e = data.get(rowIndex);
		switch (columnIndex) {
		case 0: return e.getMat();
		case 1: return e.getNom();
		case 2: return e.getSal();
		default: return null;
		}
	}

}
