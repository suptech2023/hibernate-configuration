package com.suptech.service;

import java.awt.Desktop;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.suptech.dao.DataSourceFactory;
import com.suptech.model.Employe;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class EmployeDao {
	
	
	private final DataSource dataSource;

	public EmployeDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public String insert(Employe e) {
		String result="";
		try {
			//Préparation de la requête SQL
			String sql="insert into Employe(mat,nom,sal) values(?,?,?)";
			Connection con=dataSource.getConnection();
			PreparedStatement preparedStatement=con.prepareStatement(sql);
				preparedStatement.setInt(1, e.getMat());
				preparedStatement.setString(2, e.getNom());
				preparedStatement.setFloat(3, e.getSal());
				preparedStatement.executeUpdate();
				result="Employe mat :"+e.getMat()+" Inserted";
			
			
		} catch (Exception e2) {
			result="PB INSERT :"+e2.getMessage();
		}
		return result;
	}
	public void update(Employe e) {
		try {
			//Préparation de la requête SQL
			String sql="update  Employe SET sal=? WHERE mat = ?";
			Connection con=dataSource.getConnection();
			PreparedStatement preparedStatement=con.prepareStatement(sql);
				preparedStatement.setFloat(1, e.getSal());
				preparedStatement.setInt(2, e.getMat());
				preparedStatement.executeUpdate();
				System.out.println("Employe updated ");
			
			
		} catch (Exception e2) {
			System.err.println("PB UPDATE :"+e2.getMessage());
		}
		
	}
	public boolean delete(int mat ) {
		try {
			//Préparation de la requête SQL
			String sql="delete from  Employe WHERE mat = ?";
			Connection con=dataSource.getConnection();
			PreparedStatement preparedStatement=con.prepareStatement(sql);
				preparedStatement.setInt(1, mat);
				int result=preparedStatement.executeUpdate();
				return result>0;
			
			
		} catch (Exception e2) {
			e2.getStackTrace();
			return false;
		}
		
	}
	
	public List<Employe> getAllEmploye(){
		List<Employe> employes=new ArrayList<Employe>();
		try {
			String sql="select * from Employe";
			Connection con=dataSource.getConnection();
			PreparedStatement preparedStatement=con.prepareStatement(sql);
			ResultSet result=preparedStatement.executeQuery();
			while(result.next()) {
				Employe e=new Employe();
				e.setMat(result.getInt(1));
				e.setNom(result.getString(2));
				e.setSal(result.getFloat(3));
				employes.add(e);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return employes;
	}
	
	public void loadReportByMat(int mat) {
		List<Employe> employes=getAllEmploye();
		//Préparation du Datasource
		JRBeanCollectionDataSource datasource=new JRBeanCollectionDataSource(employes);
		//Chargement du rapport
		InputStream reportStream=getClass().getResourceAsStream("/reports/employeByMat.jrxml");
		try {
			//Préparation de paramètre
			Map parametrs=new HashMap();
			parametrs.put("mat",mat);
			
			//Compilation du rapport
			JasperReport jasperReport=JasperCompileManager.compileReport(reportStream);
			//Exécution du rapport
			//Mise à jour 1
			JasperPrint jasperPrint=JasperFillManager.fillReport(jasperReport, parametrs,DataSourceFactory.getDataSource().getConnection());
			//Export vers PDF
			//mise à jour 2
			String out = "employeReport.pdf";
			JasperExportManager.exportReportToPdfFile(jasperPrint,out);
			//Ouverture de l'Etat
			Desktop desktop=Desktop.getDesktop();
			desktop.open(new File(out));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		public void loadReport() {
			List<Employe> employes=getAllEmploye();
			//Préparation du Datasource
			JRBeanCollectionDataSource datasource=new JRBeanCollectionDataSource(employes);
			//Chargement du rapport
			InputStream reportStream=getClass().getResourceAsStream("/reports/employeReport.jrxml");
			try {
				//Compilation du rapport
				JasperReport jasperReport=JasperCompileManager.compileReport(reportStream);
				//Exécution du rapport
				//Mise à jour 1
				JasperPrint jasperPrint=JasperFillManager.fillReport(jasperReport, null,datasource);
				//Export vers PDF
				//mise à jour 2
				String out = "employeReport.pdf";
				JasperExportManager.exportReportToPdfFile(jasperPrint,out);
				//Ouverture de l'Etat
				Desktop desktop=Desktop.getDesktop();
				desktop.open(new File(out));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
	
	
	
	
	
	
	
	

}
