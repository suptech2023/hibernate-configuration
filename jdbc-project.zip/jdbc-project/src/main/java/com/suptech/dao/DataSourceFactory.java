package com.suptech.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DataSourceFactory {
	
	private static HikariDataSource ds;
	
	static {
	Properties props=new Properties();
	InputStream input=DataSourceFactory.class.getClassLoader().getResourceAsStream("db-config.properties");
	try {
		props.load(input);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		HikariConfig config=new HikariConfig();
		config.setJdbcUrl(props.getProperty("jdbc.url"));
		config.setUsername(props.getProperty("jdbc.username"));
		config.setPassword(props.getProperty("jdbc.password"));
		config.setMaximumPoolSize(Integer.parseInt(props.getProperty("hickari.size")));
		config.setMinimumIdle(Integer.parseInt(props.getProperty("hickari.minimumIdl")));
		config.setConnectionTimeout(Integer.parseInt(props.getProperty("hickari.timeout")));
		config.setPoolName(props.getProperty("hickari.poolName"));
		ds=new HikariDataSource(config);
	}
	
	public static DataSource getDataSource() {
		return ds;
	}
	

}
