package com.suptech.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import com.suptech.canvas.EmployeTableModel;
import com.suptech.dao.DataSourceFactory;
import com.suptech.model.Employe;
import com.suptech.service.EmployeDao;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class EmployeView {

	private JFrame frame;
	private JTextField mat;
	private JTextField nom;
	private JTextField sal;
	private JTable table;
	private EmployeTableModel employeModel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeView window = new EmployeView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EmployeView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		employeModel=new EmployeTableModel();
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 0, 0));
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 16));
		frame.setBounds(100, 100, 884, 541);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Gestion des employés");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(126, 38, 215, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Matricule :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(37, 89, 125, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Nom :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(37, 137, 69, 20);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Salaire :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3.setBounds(37, 181, 69, 20);
		frame.getContentPane().add(lblNewLabel_3);
		
		mat = new JTextField();
		mat.setBounds(168, 86, 146, 26);
		frame.getContentPane().add(mat);
		mat.setColumns(10);
		
		nom = new JTextField();
		nom.setBounds(168, 125, 146, 26);
		frame.getContentPane().add(nom);
		nom.setColumns(10);
		
		sal = new JTextField();
		sal.setBounds(168, 178, 146, 26);
		frame.getContentPane().add(sal);
		sal.setColumns(10);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employe employe=new Employe();
				employe.setMat(Integer.parseInt(mat.getText()));
				employe.setNom(nom.getText());
				employe.setSal(Float.parseFloat(sal.getText()));
				EmployeDao employeDao=new EmployeDao(DataSourceFactory.getDataSource());
				JOptionPane.showMessageDialog(null,employeDao.insert(employe),"INFO",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnInsert.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnInsert.setBounds(15, 231, 115, 29);
		frame.getContentPane().add(btnInsert);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnDelete.setBounds(145, 231, 115, 29);
		frame.getContentPane().add(btnDelete);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnUpdate.setBounds(280, 231, 115, 29);
		frame.getContentPane().add(btnUpdate);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(46, 307, 722, 135);
		frame.getContentPane().add(scrollPane);
		EmployeDao service=new EmployeDao(DataSourceFactory.getDataSource());
		employeModel.setData(service.getAllEmploye());
		table = new JTable(employeModel);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Load Employes");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				service.loadReport();
			}
		});
		btnNewButton.setBounds(405, 231, 164, 29);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Load By Mat");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				service.loadReportByMat(Integer.parseInt(mat.getText()));
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(579, 231, 130, 28);
		frame.getContentPane().add(btnNewButton_1);
	}
}
