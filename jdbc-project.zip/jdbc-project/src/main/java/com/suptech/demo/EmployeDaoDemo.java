package com.suptech.demo;

import com.suptech.dao.DataSourceFactory;
import com.suptech.model.Employe;
import com.suptech.service.EmployeDao;

public class EmployeDaoDemo {
	
	
	public static void main(String[] args) {
		
		Employe employe=new Employe();
		EmployeDao employeDao=new EmployeDao(DataSourceFactory.getDataSource());
		
		employe.setMat(1);employe.setNom("New Name");employe.setSal(95600);
		
		employeDao.update(employe);
	}

}
