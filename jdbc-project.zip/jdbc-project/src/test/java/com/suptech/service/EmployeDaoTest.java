package com.suptech.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.suptech.dao.DataSourceFactory;

public class EmployeDaoTest {

	@Test
	void getAllEMployeTest() {
		EmployeDao employeDao=new EmployeDao(DataSourceFactory.getDataSource());
		assertEquals(employeDao.getAllEmploye().size(),4);
	}
}
